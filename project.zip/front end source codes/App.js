import React, { useState } from 'react';
import axios from 'axios';

function App() {
  const [city, setCity] = useState('LA');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [k, setK] = useState(4);
  const [result, setResult] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (type) => {
    try {
      const response = await axios.post(`http://localhost:5000/api/run_${type}`, {
        city,
        start: startDate,
        end: endDate,
        k: parseInt(k, 10) // Ensuring the value of k is an integer
      });
      setResult(JSON.stringify(response.data, null, 2));
      setError('');
    } catch (err) {
      setError('Error fetching data.');
      setResult('');
    }
  };

  return (
    <div className="App">
      <h1>Electricity Demand Clustering & Forecasting</h1>

      <div className="form-container">
        <div>
          <label>Select City:</label>
          <select value={city} onChange={(e) => setCity(e.target.value)}>
            <option value="LA">LA</option>
            <option value="Dallas">Dallas</option>
            <option value="Seattle">Seattle</option>
            <option value="NYC">NYC</option>
            <option value="Houston">Houston</option>
            <option value="Phoenix">Phoenix</option>
            <option value="San Jose">San Jose</option>
            <option value="San Diego">San Diego</option>
            <option value="San Antonio">San Antonio</option>
            <option value="Philadelphia">Philadelphia</option>
          </select>
        </div>

        <div>
          <label>Start Date:</label>
          <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
        </div>

        <div>
          <label>End Date:</label>
          <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
        </div>

        <div>
          <label>Number of Clusters (k):</label>
          <input type="number" value={k} onChange={(e) => setK(e.target.value)} min="2" max="10" />
        </div>

        <button onClick={() => handleSubmit('clustering')}>Run Clustering</button>
        <button onClick={() => handleSubmit('predictive_modeling')}>Run Predictive Modeling</button>
      </div>

      {error && <div className="error">{error}</div>}
      <pre>{result}</pre>

      <style>
        {`
          /* Global Styling */
          body {
            font-family: 'Roboto', sans-serif;
            background-color: #f5f5f5;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
          }

          /* Header */
          h1 {
            color: #4c51bf;
            font-size: 32px;
            margin-bottom: 20px;
          }

          /* Form Container */
          .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            width: 350px;
          }

          /* Form Elements */
          label {
            font-weight: bold;
            font-size: 14px;
            margin-top: 10px;
            display: block;
          }

          input,
          select {
            width: 100%;
            padding: 8px;
            margin-top: 8px;
            border-radius: 4px;
            border: 1px solid #ddd;
            font-size: 14px;
          }

          button {
            width: 100%;
            padding: 10px;
            margin-top: 15px;
            background-color: #4c51bf;
            color: white;
            font-weight: bold;
            border: none;
            border-radius: 4px;
            cursor: pointer;
          }

          button:hover {
            background-color: #3c43b2;
          }

          /* Error Message */
          .error {
            color: red;
            margin-top: 10px;
            font-size: 14px;
          }

          /* Result Display */
          pre {
            background-color: #f8f8f8;
            padding: 20px;
            border-radius: 8px;
            max-width: 800px;
            width: 100%;
            margin-top: 20px;
            font-size: 14px;
            overflow: auto;
          }

          /* Optional Media Query for Responsiveness */
          @media (max-width: 768px) {
            .form-container {
              width: 90%;
            }

            h1 {
              font-size: 28px;
            }
          }
        `}
      </style>
    </div>
  );
}

export default App;
