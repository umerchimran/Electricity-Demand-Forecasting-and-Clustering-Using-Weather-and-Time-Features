import os
import json
import pandas as pd
import nbformat
import subprocess
from flask import Flask, request, jsonify, send_from_directory
from nbconvert import PythonExporter

# Set up Flask to serve static files from ../public
app = Flask(__name__, static_folder=os.path.abspath('../public'), static_url_path='')

# Load dataset
dataset = pd.read_csv(r"D:\DM proj\archive\app-react\backend\whole_merged_data.csv", low_memory=False)


# Function to run Jupyter notebook (.ipynb file) and return the result
def run_notebook(notebook_path, params):
    with open(notebook_path) as f:
        notebook_content = nbformat.read(f, as_version=4)

    python_exporter = PythonExporter()
    python_code, _ = python_exporter.from_notebook_node(notebook_content)

    temp_py_file = 'temp_script.py'
    with open(temp_py_file, 'w') as temp_file:
        temp_file.write(python_code)

    process = subprocess.Popen(['python', temp_py_file] + params, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = process.communicate()

    if stderr:
        return {"error": stderr.decode()}
    return {"output": stdout.decode()}

# Serve index.html when visiting root
@app.route('/')
def index():
    return send_from_directory(app.static_folder, 'index.html')

# Serve static files like App.js, CSS, etc.
@app.route('/<path:path>')
def serve_static(path):
    return send_from_directory(app.static_folder, path)

@app.route('/api/run_clustering', methods=['POST'])
def clustering():
    data = request.get_json()
    city = data['city']
    start_date = data['start']
    end_date = data['end']
    k = data['k']

    filtered_data = dataset[(dataset['City name'] == city) & (dataset['Timestamp'] >= start_date) & (dataset['Timestamp'] <= end_date)]
    filtered_data.to_csv('filtered_data.csv', index=False)

    result = run_notebook('clustering.ipynb', ['filtered_data.csv', str(k)])
    return jsonify(result)

@app.route('/api/run_predictive_modeling', methods=['POST'])
def predictive_modeling():
    data = request.get_json()
    city = data['city']
    start_date = data['start']
    end_date = data['end']

    filtered_data = dataset[(dataset['City name'] == city) & (dataset['Timestamp'] >= start_date) & (dataset['Timestamp'] <= end_date)]
    filtered_data.to_csv('filtered_data.csv', index=False)

    result = run_notebook('predictive_modeling.ipynb', ['filtered_data.csv'])
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True)
